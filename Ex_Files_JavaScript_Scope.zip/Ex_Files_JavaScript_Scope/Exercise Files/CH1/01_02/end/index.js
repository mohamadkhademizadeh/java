var warrior = 'Ninja';

const screamWarrior = () => {
    let warrior2 = 'Samurai';
    console.log(warrior, warrior2);
}

screamWarrior();

console.log(warrior, warrior2);

