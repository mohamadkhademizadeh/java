if (typeof registerPaint !== 'undefined') {
    // define a class to implement the paint worklet
    class SampleCSSPaint {
        // TODO: declare the properties that the class has access to

        // TODO: fill out the paint function to do the drawing work
        paint(ctx, size, props) {

        }
    }

    // TODO: register the paint worklet for CSS

}